// New Binding

function Automovil(modelo, color) {
    this.modelo = modelo;
    this.color = color;
}
const auto = new Automovil('Camaro', 'Negro');
console.log(auto);