try {
    throw new Error('Algo salió mal');
} catch {
    console.log('Hubo un error bastante grave...');
}