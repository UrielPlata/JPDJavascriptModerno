const correo = '    correo@correo.com    ';


console.log(correo);
console.log(correo.trimStart());
console.log(correo.trimEnd());
console.log(correo.trim() );