const edades = [8,10,9, 11, [13,18, 20, [18,20,21]]];

console.log( edades.flat(Infinity) );