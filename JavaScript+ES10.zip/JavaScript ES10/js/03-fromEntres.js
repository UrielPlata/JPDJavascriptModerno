const map = new Map([ 
    ['nombre', 'Producto 1'], 
    ['precio', 20] 
]);